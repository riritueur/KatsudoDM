<p> Ajouter une entrée 
  <button type="button" class="btn btn-default btn-circle" data-toggle="modal" data-target="#myModal2"><i class="fa fa-plus"></i>
  </button>
</p>
